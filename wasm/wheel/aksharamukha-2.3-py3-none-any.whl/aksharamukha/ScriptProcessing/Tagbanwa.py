# -*- coding: utf-8 -*-

# Tagbanwa's own Fix logic, consolidated out of ConvertFix.py (batch migration -
# see ScriptProcessing/Tamil.py for the full rationale/pattern this follows).
# PostProcess/ConvertFix are imported LOCALLY inside each function that
# needs them (not at module level) - required to avoid a load-order-
# dependent circular import, since ConvertFix.py re-exports names from
# here. See ScriptProcessing/Tamil.py for the full explanation.

import re

# ---- Fix (encode/decode conversion logic) ----

# internal
def _FixTagbanwaEncode(Strng):

    """Inserts the gemination sign for doubled consonants when encoding into Tagbanwa."""
    from .. import PostProcess
    Strng = PostProcess.InsertGeminationSign(Strng, 'Tagbanwa')

    return Strng

# internal
def _FixTagbanwaDecode(Strng):

    """No-op decode fix for Tagbanwa; no additional corrections are currently applied."""
    pass

    return Strng

# internal
def FixTagbanwa(Strng, reverse=False):

    """Dispatches to the Tagbanwa encode or decode fix routine based on the reverse flag."""
    return _FixTagbanwaDecode(Strng) if reverse else _FixTagbanwaEncode(Strng)
