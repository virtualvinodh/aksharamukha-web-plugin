# -*- coding: utf-8 -*-

# Gujarati's own Fix/pre-option/post-option logic, consolidated out of
# ConvertFix.py/PreProcess.py/PostProcess.py (batch migration - see
# ScriptProcessing/Tamil.py for the full rationale/pattern this follows).
# ConvertFix/PreProcess/PostProcess are imported LOCALLY inside each
# function that needs them (not at module level) - required to avoid a
# load-order-dependent circular import, since these three modules
# re-export names from here. See ScriptProcessing/Tamil.py.

import re

# ---- Fix (encode/decode conversion logic) ----

# internal
def _FixGujaratiEncode(Strng):

    """Retains Indic dandas and merges nukta-marked ja/sha into the dedicated Gujarati letter ૹ when encoding."""

    from .. import PostProcess
    Strng = PostProcess.RetainDandasIndic(Strng, 'Gujarati', True)
    Strng = Strng.replace('જ઼઼', 'ૹ').replace('શ઼', 'ૹ')

    return Strng

# internal
def _FixGujaratiDecode(Strng):

    """Retains Indic dandas and expands the Gujarati letter ૹ back into nukta-marked ja/sha when decoding."""

    from .. import PostProcess
    Strng = PostProcess.RetainDandasIndic(Strng, 'Gujarati')
    Strng = Strng.replace('ૹ', 'જ઼઼').replace('ૹ', 'શ઼')

    return Strng

# internal
def FixGujarati(Strng, reverse=False):

    """Dispatches to the Gujarati encode or decode fix routine depending on conversion direction."""

    return _FixGujaratiDecode(Strng) if reverse else _FixGujaratiEncode(Strng)

# ---- Pre-processing options ----

# frontend
def SchwaFinalGujarati(Strng):

    """Deletes the inherent schwa only at the end of a word - राम → rām."""
    from .. import PreProcess as PP

    Strng = PP.RemoveFinal(Strng, 'Gujarati')

    return Strng
