# -*- coding: utf-8 -*-

# Sogo's own Fix/pre-option/post-option logic, consolidated out of
# ConvertFix.py/PreProcess.py/PostProcess.py (batch migration - see
# ScriptProcessing/Tamil.py for the full rationale/pattern this follows).
#
# SogoReshAyinDaleth independently defines the SAME option name in both
# PreProcess.py and PostProcess.py, as two genuinely different functions
# (pre-side does roughly one direction of a transform, post-side roughly
# the inverse) - can't both be a bare top-level `def` of the identical
# name in one file. Suffixed _pre/_post here; PreProcess.py/PostProcess.py
# each re-export their own half under the ORIGINAL (unsuffixed) name via
# `import X_pre as X` / `import X_post as X`, so the public option name
# (post_options=['X']/pre_options=['X']) is completely unchanged.

import re

# ---- Pre-processing options ----

# frontend
def SogoReshAyinDaleth_pre(Strng):
    """Replaces the Sogdian resh-ayin-daleth ligature character with a bracketed private-use-area placeholder sequence before processing."""
    Strng = Strng.replace('𐼘', '[\uEA01-\uEA02-\uEA06]') # resh yin daleth

    return Strng

# ---- Post-processing options ----

# frontend
def SogoReshAyinDaleth_post(Strng):
    """Replaces a Sogdian private-use character with the resh-ayin-daleth ligature character after processing."""
    Strng = Strng.replace('𐼓','𐼘')

    return Strng
